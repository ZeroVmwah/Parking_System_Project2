import java.util.Scanner;

public class ParkPaying {
    public static int loyalCustomer;

    public static int Pay(){
        int total = 0;

    Scanner scanner = new Scanner(System.in);
    System.out.println("How many years have you been our client for ;)");
    String input = scanner.nextLine();
    try{
        loyalCustomer = Integer.parseInt(input);
    }
    catch (NumberFormatException e){
        System.out.println("Input should be an integer, Try again..");
        Pay();
    }
     if (loyalCustomer < 3){
         System.out.println("Parking cost is default value of 30$.");
         total = Membership(30);
     }
     else if (loyalCustomer <= 6){
         System.out.println("Parking has a reduced cost value for loyal clients of 25$.");
         total = Membership(25);
     }
     else {
         System.out.println("Parking cost is reduced for our most loyal clients to 20$.");
         total = Membership(20);
     }
     return total;
    }

    public static int Membership(int fee){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Do you have an extra membership plan with our parking?");
        String member = scanner.nextLine();
        switch(member) {
            case "yes":
                System.out.print("Our membership reduces your fee by 20% for a total fee of: ");
                fee = 80 * fee / 100;
                System.out.println(fee + "$");
                break;
            case "no":
                System.out.print("Your total fee remains: ");
                System.out.println(fee + "$");
                break;
            default:
                System.out.println("Invalid input! Try again.");
                Pay();
        }
        return fee;
    }
}
