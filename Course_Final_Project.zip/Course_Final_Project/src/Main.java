import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;
public class Main {
public static FileWriter writer;
    public static void main(String[] args) {
        try {
            writer = new FileWriter("Parking System.txt");
        } catch (IOException e) {
            e.getStackTrace();
        }
        Access();
        IterationOfUsers();
        try {
            writer.flush();
        } catch (IOException e) {
            e.getStackTrace();
        }
    }

    public static void Access(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Hello! Input you role for this parking (client or an administrator)");
        String role = scanner.nextLine();
        if (role.equals("client")){
            Client newPark = new Client();
            newPark.CarDetails(newPark);
            newPark.setParkingSpace(Parking.SpaceSelect());
            newPark.setPriceFee(ParkPaying.Pay());

            try {
                writer.write(String.format("Name: %s - Car: %s, Number: %s, parked in space: %s " +
                                "has to pay %s dollars.", newPark.getName(),
                        newPark.getModel(), newPark.getRegistration(),
                        newPark.getParkingSpace(), newPark.getPriceFee()));
                writer.write("\r\n");
            } catch (IOException e) {
                e.getStackTrace();
            }

        } else if (role.equals("administrator")) {
            System.out.println("You can view the free spaces and view the info for the ones that are taken.");
            System.out.println("Free and taken spaces in parking: ");
            for (int i = 0; i < Parking.parkingSlots.length; i++) {
                for (int j = 0; j < Parking.parkingSlots[i].length; j++) {
                    System.out.print(Parking.parkingSlots[i][j] + " ");
                }
                System.out.println();
            }
            System.out.println("Info for taken spaces: view doc after reviewing spaces:)");

        }
        else{
            System.out.println("Invalid input! Please enter a valid role.");
            Access();
        }
    }

    public static void IterationOfUsers(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Do you want to access again? (yes or no)");
        String replay = scanner.nextLine();
        switch(replay) {
            case "yes":
                Access();
                IterationOfUsers();
                break;
            case "no":
                System.out.println("Thank you for using this parking!");
                break;
            default:
                System.out.println("Invalid input! Try again.");
                IterationOfUsers();
        }
    }
}