import java.util.Scanner;

public class Parking {
    public static String[][] parkingSlots = {{"A1", "A2", "A3", "A4"},
                                             {"B1", "B2", "B3", "B4"},
                                             {"C1", "C2", "C3", "C4"},
                                             {"D1", "D2", "D3", "D4"}};
    public static String SpaceSelect(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select an available parking space from the following:");
        for (int i = 0; i < parkingSlots.length; i++) {
            for (int j = 0; j < parkingSlots[i].length; j++) {
                System.out.print(parkingSlots[i][j] + " ");
            }
            System.out.println();
        }

        String slot = scanner.nextLine();
        for (int i = 0; i < parkingSlots.length; i++) {
            for (int j = 0; j < parkingSlots[i].length; j++) {
                if (slot.compareTo(parkingSlots[i][j]) == 0) {
                    parkingSlots[i][j] = "taken";
                    return slot;
                }
            }
        }
        System.out.println("Please select a VALID space!");
        SpaceSelect();
        return slot;
    }

}
