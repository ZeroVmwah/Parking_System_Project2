public interface ICarParts {
    String getModel();
    void setModel(String model);
    String getRegistration();
    void setRegistration(String registration);
}
