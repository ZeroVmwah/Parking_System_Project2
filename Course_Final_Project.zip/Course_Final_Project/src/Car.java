abstract class Car implements ICarParts{
    private String model;
    private String registration;

    public Car(String model, String registration) {
        setModel(model);
        setRegistration(registration);
    }
    public Car(){

    }
    public String getModel(){
        return model;
    }
    public void setModel(String model){
        this.model = model;
    }

    public String getRegistration(){
        return registration;
    }
    public void setRegistration(String registration){
        this.registration = registration;
    }
}
