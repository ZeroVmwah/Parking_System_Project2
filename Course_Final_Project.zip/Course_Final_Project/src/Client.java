import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class Client extends Car {
    private String name;
    private String parkingSpace;
    private int priceFee;

    public Client(String name, String model, String registration) {
        super(model, registration);
    }
    public Client() {
    }

    public void CarDetails(Client object) {
        Scanner scanner = new Scanner(System.in);

        object.setName();

        System.out.println("What's the model of your vehicle?");
        String inputModel = scanner.nextLine();
        if (inputModel.isBlank()) {
            System.out.println("Car model cannot be blank!");
            System.out.println("What's the model of your vehicle?");
            inputModel = scanner.nextLine();
        }
            setModel(inputModel);

        System.out.println("What's the registration number of your vehicle?");
        String inputReg = scanner.nextLine();
        if (inputReg.isBlank()) {
            System.out.println("Registration number cannot be blank!");
            System.out.println("What's the registration number of your vehicle?");
            inputReg = scanner.nextLine();
        }
            setRegistration(inputReg);
    }
    public void setName(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("What's your name and surname?");
        name = scanner.nextLine();
        if (name.isBlank()){
            System.out.println("Name cannot be blank!");
            setName();
        }
        else {
            this.name = name;
        }
    }
    public String getName(){
        return name;
    }

    public void setParkingSpace(String parkingSpace) {
        this.parkingSpace = parkingSpace;
    }

    public String getParkingSpace() {
        return parkingSpace;
    }

    public int getPriceFee() {
        return priceFee;
    }

    public void setPriceFee(int priceFee) {
        this.priceFee = priceFee;
    }
}
